fx_version 'cerulean'
game 'gta5'
lua54 "yes"

author 'Splushy'
description 'Gym'
version '1.0.0'

this_is_a_map "yes"

escrow_ignore {
    'stream/*.ytd'
  }